1. Pendaftaran PPDB
a. Gelombang 1 (1 Sep s.d 31 Okt). Test tertulis dan interview (3 Nopember 2022)
b. Gelombang 2 ( 10 Nop s.d. 10 Desember. Test dan interview ( 12 Desember).
c. Gelombang 3 (19 Des s.d.4 Feb 2023. Test dan interview (6 Feb 2023)

Trus yg off line, bisa ke sekolah tiap hari kerja (7.30 s d. 12.00)

2. Jalur PPDB
a. Jalur Istimewa. 
b. Jalur Prestasi
c. Jalur khusus (Dari seluruh lulusan SD katolik)
d. Jalur umum.


https://konawe.iixcp.rumahweb.net:2083/

smpxaver
L9Ngp5y3T.-s9D
